<?php

class Base
{
    private $conn = null;
    private $host;
    private $user;
    private $pass;
    private $db_name;

    function __construct($host, $user, $pass, $db_name)
    {
        $this->host = $host;
        $this->user = $user;
        $this->pass = $pass;
        $this->db_name = $db_name;
    }

    public function connect()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db_name);

        if (mysqli_connect_errno())
            throw new Exception("Connect failed - " . mysqli_connect_error());
    }

    public function disconnect()
    {
        if ($this->conn !== null) {
            $this->conn->close();
            $this->conn = null;
        }
    }

    public function getConn()
    {
        return $this->conn;
    }
}