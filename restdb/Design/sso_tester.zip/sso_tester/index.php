<?php
set_time_limit(0);
ob_end_flush();
ob_implicit_flush();

require_once "tester.php";

$tester = new Tester('homol', 'vivo');

$result = $tester->run(26, 'vivo', 2);

echo '<pre>';
print_r($result);
echo '</pre>';

