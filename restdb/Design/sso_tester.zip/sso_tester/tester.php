<?php

require_once "base.php";
require_once "mcrypt.php";

class Tester
{
    protected $config = array(
        'production' => array(
            'vivo' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-vivo.auth.srv.br'
            ),
            'gvt' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-gvt.auth.srv.br'
            ),
            'algar' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-algar.auth.srv.br'
            ),
            'tim' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-tim.auth.srv.br'
            ),
            'nextel' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-nextel.auth.srv.br'
            ),
            'oi' => array(
                'host' => '10.54.133.195',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG',
                'db_name' => 'base_vivo',
                'sso_url' => 'https://br-oi.auth.srv.br'
            )
        ),
        'homol' => array(
            'vivo' => array(
                'host' => 'vivo-homol-virginia.cegp3ffftjdi.us-east-1.rds.amazonaws.com',
                'user' => 'homol_base_vivo', // 'restdb',
                'pass' => '0ioNLcyOTriu4tw', //'1eMbBqLu2KxPL08AzIHdkPsXSmn0ZYBA',
                'db_name' => 'homol_base_vivo',
                'sso_url' => 'https://br-vivo.auth.srv.br'
            ),
            'gvt' => array(
                'host' => 'dev01-bd.clkadcgt8mnt.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_gvt',
                'sso_url' => 'https://br-gvt-homol.auth.srv.br'
            ),
            'tasa' => array(
                'host' => 'db-tasa-homol.c0wqbjh2t9ai.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => '71eNxzSYuFDIJLUjFbalYdXP6mcnAIwk',
                'db_name' => 'db_tasa_homol',
                'sso_url' => 'https://br-tasa-homol.auth.srv.br'
            ),
            'hero' => array(
                'host' => 'hero-homol.clkadcgt8mnt.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => 'vwQOixgtmcaCjdFr12jueGXoN8W9VLQ9',
                'db_name' => 'db_hero_homol',
                'sso_url' => 'https://br-hero-homol.auth.srv.br'
            ),
            'ctbc' => array(
                'host' => 'dev01-bd.clkadcgt8mnt.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_algarcentraldeseguranca',
                'sso_url' => 'https://br-ctbc-homol.auth.srv.br'
            ),
            'algar' => array(
                'host' => 'dev01-bd.clkadcgt8mnt.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_algarcentraldeseguranca',
                'sso_url' => 'https://br-algar-homol.auth.srv.br'
            ),
            'tim' => array(
                'host' => '127.0.0.1', // 'mysql-homol-dht.fsvas.com',
                'user' => 'restdb',
                'pass' => 'OjV7YbRGvr5hibG', // 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_tim',
                'sso_url' => 'https://br-tim-homol.auth.srv.br'
            ),
            'nextel' => array(
                'host' => 'dev01-bd.clkadcgt8mnt.sa-east-1.rds.amazonaws.com',
                'user' => 'restdb',
                'pass' => 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_nextel',
                'sso_url' => 'https://br-nextel-homol.auth.srv.br'
            ),
            'oi' => array(
                'host' => 'mysql-homol-dht.fsvas.com',
                'user' => 'restdb',
                'pass' => 'Lz1PVysKc8dLbrUbOuiQmH6o25SJwsj7',
                'db_name' => 'base_tim',
                'sso_url' => 'https://br-oi-homol.auth.srv.br'
            )
        )
    );

    private $conn;
    private $sso_url;

    function __construct($ambient, $op)
    {
        $host = $this->config[$ambient][$op]['host'];
        $user = $this->config[$ambient][$op]['user'];
        $pass = $this->config[$ambient][$op]['pass'];
        $db_name = $this->config[$ambient][$op]['db_name'];

        $base = new Base($host, $user, $pass, $db_name);
        $base->connect();
        $this->conn = $base->getConn();

        $this->sso_url = $this->config[$ambient][$op]['sso_url'];
    }

    public function run($product_id, $base, $limit_users = 10, $limit_client_id = -1)
    {
        $return = array();

        $stmt = $this->conn->prepare("SELECT client_id, config FROM produtos_oauth WHERE produto_id = ? ORDER BY rand() LIMIT ?");
        $stmt->bind_param("ii", $product_id, $limit_client_id);
        $stmt->execute();

        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $client_id = $row['client_id'];
            $return[$client_id] = array();

            $config = json_decode(str_replace("'", '"', $row['config']), true);

            $sql = "SELECT vw.{$config[$base]['extref']} AS extref, c.senha AS password FROM VIEW_SSO_USER_DATA AS vw
                JOIN clientes AS c ON vw.cliente_id = c.id
                WHERE vw.client_id = ?
                ORDER BY rand()
                LIMIT ?";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                $return[$client_id] = 'config error';
                continue;
            }

            $stmt->bind_param("si", $client_id, $limit_users);
            $stmt->execute();

            $users = $stmt->get_result();
            while ($user = $users->fetch_assoc()) {
                $login = $this->login($user['extref'], MCrypt::decrypt($user['password']), $client_id);

                $return[$client_id][] = array($user['extref'], $login);
            }
        }

        return $return;
    }

    public function login($email, $password, $client_id)
    {
        $query_string = array(
            'response_type' => 'code',
            'client_id' => $client_id,
            'redirect_uri' => 'http://localhost/',
        );

        $url = $this->sso_url . '/login?next=' . urlencode('/oauth/authorize?' . http_build_query($query_string));
        $cookie = "cookie.txt";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("email" => $email, "password" => $password));
        curl_exec($ch);
        // $error = curl_error($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        if ($info['http_code'] != '200')
            return $info['http_code'];

        $url = $info['url'];
        $parts = parse_url($url);
        parse_str($parts['query'], $query);
        if (isset($query['error'])) return $query['error'];

        if (isset($query['error']))
            return $query['error'];

        if (isset($query['ssoerror']))
            return $query['ssoerror'];

        if (isset($query['code']))
            return true;
    }
}